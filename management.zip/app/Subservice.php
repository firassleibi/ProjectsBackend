<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subservice extends Model
{
    //
    protected $table = 'sub_services';
}
