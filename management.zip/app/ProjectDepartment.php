<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectDepartment extends Model
{
    //
    protected $table = 'projects_departments';
}
